#!/bin/sh
set -e

. ./ci/build-common.sh

mkdir -p subprojects
git clone https://code.videolan.org/videolan/libplacebo.git \
    --recurse-submodules --shallow-submodules \
    --depth=1 --branch v7.387.0 subprojects/libplacebo

meson setup build $common_args \
 -Dlibplacebo:vulkan=disabled \
 -Dlua=enabled \
 -Dsixel=enabled \
 -Dwayland=enabled
meson compile -C build
./build/mpv -v --no-config
