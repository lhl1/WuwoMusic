/*
 * Based on GyS-TermIO v2.0 (for GySmail v3) (copyright (C) 1999 A'rpi/ESP-team)
 *
 * This file is part of mpv.
 *
 * mpv is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * mpv is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with mpv.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MPLAYER_GETCH2_H
#define MPLAYER_GETCH2_H

#include <stdarg.h>
#include <stdbool.h>

#include "misc/bstr.h"

#define TERM_ESC_GOTO_YX            "\033[%d;%df"
#define TERM_ESC_HIDE_CURSOR        "\033[?25l"
#define TERM_ESC_RESTORE_CURSOR     "\033[?25h"
#define TERM_ESC_SYNC_UPDATE_BEGIN  "\033[?2026h"
#define TERM_ESC_SYNC_UPDATE_END    "\033[?2026l"

#define TERM_ESC_CLEAR_SCREEN       "\033[2J"
#define TERM_ESC_ALT_SCREEN         "\033[?1049h"
#define TERM_ESC_NORMAL_SCREEN      "\033[?1049l"

#define TERM_ESC_ENABLE_MOUSE       "\033[?1003h"
#define TERM_ESC_DISABLE_MOUSE      "\033[?1003l"

#define TERM_ESC_REVERSE_COLORS     "\033[7m"
#define TERM_ESC_CLEAR_COLORS       "\033[0m"

struct input_ctx;

/* Global initialization for terminal output. */
void terminal_init(void);

/* Setup ictx to read keys from the terminal */
void terminal_setup_getch(struct input_ctx *ictx);

/* Undo terminal_init(), and also terminal_setup_getch() */
void terminal_uninit(void);

/* Return whether the process has been backgrounded. */
bool terminal_in_background(void);

/* Get terminal-size in columns/rows. */
void terminal_get_size(int *w, int *h);

/* Get terminal-size in columns/rows and width/height in pixels. */
void terminal_get_size2(int *rows, int *cols, int *px_width, int *px_height);

/* Enable/Disable mouse input. */
void terminal_set_mouse_input(bool enable);

/* Sets notification callback for when terminal is resized. */
bool terminal_set_resize_callback(void (*cb)(void *ctx), void *ctx);

/* Serialize writes to the terminal. */
void terminal_lock_output(void);
void terminal_unlock_output(void);

// Windows only.
int mp_console_vfprintf(void *wstream, const char *format, va_list args)
    MP_PRINTF_ATTRIBUTE(2, 0);
int mp_console_write(void *wstream, bstr str);
bool mp_check_console(void *handle);

/* Windows-only function to attach to the parent process's console */
bool terminal_try_attach(void);

#endif /* MPLAYER_GETCH2_H */
